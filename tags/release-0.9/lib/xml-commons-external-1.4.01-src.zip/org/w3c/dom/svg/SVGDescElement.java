
package org.w3c.dom.svg;

public interface SVGDescElement extends 
               SVGElement,
               SVGLangSpace,
               SVGStylable {
}
